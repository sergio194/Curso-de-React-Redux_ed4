import React from "react"
export const Task = (titleTask) => {
    <div>
        <p>{titleTask}</p>
    </div>
} 