import React from "react";
export const Title = ({content}) => <h1>{content}</h1>;
