import React from "react";
import { Title } from "./molecules/Title";

export const Header = () => <header>
    <Title content="Mis tareas"></Title>
</header>;
